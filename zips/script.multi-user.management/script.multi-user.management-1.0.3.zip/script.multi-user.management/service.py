# -*- coding: utf-8 -*-
import time

import xbmc
import xbmcaddon
from resources.lib import manager
from resources.lib.ui import open_selector
from resources.lib.watcher import TargetWatcher

ADDON = xbmcaddon.Addon()

# Intervalos de la reconciliacion de tokens (segundos)
FAST_POLL = 3    # mientras hay un usuario activo pendiente de vincular
SLOW_POLL = 30   # mantenimiento: detectar refrescos de token de Trakt

# Cadencia del vigilante de navegacion, solo si esta activado el ajuste.
# Cuanto mas corta, mas posibilidades de llegar antes de que el addon
# objetivo abra un dialogo propio y nos bloquee.
NAV_TICK = 0.25

# Tope de espera a que no quede ningun dialogo abierto. Generoso, porque
# puede haber uno del addon objetivo esperando a que el usuario lo lea.
DIALOG_TIMEOUT = 60.0



def show_selector():
    open_selector()


def ask_on_start():
    try:
        return ADDON.getSettingBool("ask_profile_on_start")
    except Exception:
        return False


def active_is_pending(db):
    """True si el usuario activo todavia no tiene token (esperando vinculacion)."""
    active = db.get("active_user")
    if not active or active not in db.get("users", {}):
        return False
    return not (db["users"][active].get("access"))


def should_prompt_for(db):
    """Politica: preguntar siempre, o solo si el perfil activo no tiene sesion."""
    if not manager.intercept_only_pending():
        return True
    return not db.get("active_user") or active_is_pending(db)


def dialog_abierto():
    """True si hay cualquier dialogo por delante.

    No basta con mirar el de ocupado: Kodi rechaza activar una ventana
    mientras haya CUALQUIER modal, y el addon objetivo puede abrir el suyo
    (por ejemplo el de vinculacion de Trakt) antes de que lleguemos.
    """
    return (xbmc.getCondVisibility("System.HasActiveModalDialog")
            or xbmc.getCondVisibility("System.HasVisibleModalDialog")
            or xbmc.getCondVisibility("Window.IsActive(busydialognocancel)")
            or xbmc.getCondVisibility("Window.IsActive(busydialog)"))


def wait_for_dialogs(monitor):
    """Espera a que no quede ningun dialogo delante.

    Devuelve False si se agota el tiempo: en ese caso NO se intenta abrir,
    porque Kodi lo rechazaria y solo se ensuciaria el log.
    """
    limite = time.time() + DIALOG_TIMEOUT
    while time.time() < limite:
        if not dialog_abierto():
            return True
        if monitor.waitForAbort(0.2):
            return False
    manager.log("watcher: hay un dialogo que no se cierra, no se abre el selector")
    return False


if __name__ == "__main__":

    monitor = xbmc.Monitor()

    # Espera a que Kodi termine de arrancar (~6s) sin bloquear el apagado
    for _ in range(30):
        if monitor.waitForAbort(0.2):
            raise SystemExit

    db = manager.load_db()
    active = db.get("active_user")

    # Mejora 6A: avisar de quien es la sesion activa al volver
    if active and active in db.get("users", {}):
        name = db["users"][active].get("name", active)
        manager.notify("MultiUser", f"Viendo como: {name}")

    # Traza de arranque. Sin esto, un servicio que no abre nada es
    # indistinguible de un servicio que no esta corriendo.
    manager.log(f"servicio arrancado: objetivo={manager.target_addon_id()} "
                f"intercept={manager.intercept_enabled()} "
                f"solo_pendientes={manager.intercept_only_pending()} "
                f"activo={active}")

    watcher = TargetWatcher(manager.target_addon_id())

    # Mostrar selector si no hay usuario activo, o si se ha pedido el modo
    # "preguntar al arrancar" (opcion C, configurable).
    if not active or ask_on_start():
        show_selector()
        # Si el usuario ha elegido perfil, la ventana ya ha lanzado el addon
        # objetivo. Esa entrada la hemos provocado nosotros: si el vigilante
        # la viera como un flanco normal volveria a preguntar al instante.
        watcher.assume_inside(time.time())

    next_reconcile = 0.0

    while not monitor.abortRequested():
        now = time.time()
        intercept = manager.intercept_enabled()

        # --- Vigilante de navegacion: se ha entrado en el addon objetivo ---
        # Kodi no anuncia la apertura de un plugin, asi que se mira la ruta
        # del contenedor. Cuando esto dispara, Palantir ya esta cargando: se
        # reacciona, no se intercepta.
        if intercept:
            path = xbmc.getInfoLabel("Container.FolderPath") or ""
            if watcher.should_prompt(path, now):
                if should_prompt_for(manager.load_db()):
                    manager.log(f"watcher: entrada en {path}, abriendo selector")
                    if wait_for_dialogs(monitor):
                        # Al elegir perfil la ventana inyecta y relanza el
                        # addon objetivo. Kodi lo invoca de nuevo y este
                        # lee el token del disco, asi que aqui no queda
                        # nada que hacer.
                        show_selector()
                else:
                    # Callarse aqui es lo que hace que el addon parezca roto:
                    # se ha entrado en el objetivo y no se abre nada. Es el
                    # caso de "solo si el perfil activo no tiene sesion" con
                    # un perfil que si la tiene.
                    manager.log(f"watcher: entrada en {path}, pero no toca "
                                f"preguntar (solo_pendientes="
                                f"{manager.intercept_only_pending()})")
                watcher.handled(time.time(), path)

        # --- Reconciliacion de tokens (auto-captura y refrescos de Trakt) ---
        if now >= next_reconcile:
            db = manager.load_db()

            name = manager.reconcile_active(db)
            if name:
                manager.notify("MultiUser", f"Sesion de {name} guardada")

            next_reconcile = now + (FAST_POLL if active_is_pending(db) else SLOW_POLL)

        interval = NAV_TICK if intercept else (
            FAST_POLL if active_is_pending(db) else SLOW_POLL)

        if monitor.waitForAbort(interval):
            break
