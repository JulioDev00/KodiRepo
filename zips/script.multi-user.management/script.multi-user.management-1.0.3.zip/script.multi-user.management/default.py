# -*- coding: utf-8 -*-
from resources.lib.ui import open_selector


def run():
    open_selector()


if __name__ == "__main__":
    run()
