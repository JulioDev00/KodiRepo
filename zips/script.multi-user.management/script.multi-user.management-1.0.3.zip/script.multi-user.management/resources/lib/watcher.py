# -*- coding: utf-8 -*-
"""Detecta que se acaba de entrar en el addon objetivo.

Kodi no anuncia la apertura de un plugin: onNotification solo cubre
Player.*, System.*, VideoLibrary.* y compania, y la navegacion no se
anuncia nunca. Asi que la unica via sin tocar Palantir ni la config de
Kodi es mirar Container.FolderPath.

Ojo con lo que esto es: se reacciona, no se intercepta. Cuando dispara,
Palantir ya ha empezado a construir su listado con el token anterior.

Este modulo no importa nada de xbmc a proposito, para poder probarlo.
"""

# Silencio tras atender una entrada. Sin esto se entra en bucle: al
# relanzar el addon objetivo la ruta vuelve a entrar y eso es otro flanco.
SUPPRESS_SECS = 5.0


class TargetWatcher:
    """Vigila las rutas que le van llegando y avisa del flanco de entrada."""

    def __init__(self, target_id, suppress_secs=SUPPRESS_SECS):
        self.target_id = target_id
        self.suppress_secs = suppress_secs
        self.prev = ""
        self.suppress_until = 0.0

    def inside(self, path):
        return bool(path) and path.startswith(f"plugin://{self.target_id}/")

    def should_prompt(self, path, now):
        """True solo en la transicion fuera -> dentro.

        Comparar contra la ruta anterior es lo que evita disparar en bucle
        y lo que hace que navegar por dentro del addon (o volver a su raiz
        desde una subcarpeta) no vuelva a preguntar.
        """
        entered = self.inside(path) and not self.inside(self.prev)
        self.prev = path

        if not entered:
            return False
        return now >= self.suppress_until

    def handled(self, now, path=None):
        """Marca una entrada como atendida y abre la ventana de silencio."""
        self.suppress_until = now + self.suppress_secs
        if path is not None:
            self.prev = path

    def assume_inside(self, now):
        """Da por atendida una entrada que no hemos llegado a ver.

        El selector del arranque lanza el addon objetivo por su cuenta si el
        usuario elige perfil, y la ruta entra sola unos ticks despues. Sin
        esto el bucle veria ese flanco como una entrada nueva y volveria a
        preguntar justo despues de haber preguntado.

        Se finge que ya estabamos dentro (para que no haya flanco) y ademas
        se abre la ventana de silencio (para cubrir los tics en los que la
        ruta todavia no se ha actualizado).
        """
        self.prev = f"plugin://{self.target_id}/"
        self.suppress_until = now + self.suppress_secs
