# -*- coding: utf-8 -*-
import json
import os
import sqlite3
import time
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()

# Valores por defecto. Se pueden sobreescribir desde los ajustes del addon
# (settings.xml) sin tocar el codigo.
DEFAULT_TARGET_ID = "plugin.video.palantir3"
# Cache de listados del addon objetivo. Es la tabla que usa el modulo
# simplecache, comun en los addons de Kodi.
DEFAULT_CACHE_DB = "cache.db"
CACHE_TABLE = "simplecache"

# Ventana de video de Kodi, la que muestra el listado del addon objetivo.
VIDEO_WINDOW = 10025

# Ventana de inicio, que es la unica que sigue viva de principio a fin. Sus
# propiedades son el buzon entre procesos: el selector puede correr en el
# del servicio o en el de un script, y asi se entienden igual.
HOME_WINDOW = 10000
RELAUNCH_PROP = "multiuser.relanzado"

DEFAULT_KEYS = {
    "access": "trakt_access_token",
    "refresh": "trakt_refresh_token",
    "slug": "trakt_slug",
    "expires": "trakt_token_expired_at",
}


def log(msg):
    xbmc.log(f"[MULTIUSER] {msg}", xbmc.LOGINFO)


def notify(title, msg, time_ms=5000):
    try:
        xbmcgui.Dialog().notification(title, msg, xbmcgui.NOTIFICATION_INFO, time_ms)
    except Exception as e:
        log(f"notify() error: {e}")


# ---------------------------------------------------------------------------
# Configuracion (lee de settings.xml, con fallback a los valores por defecto)
# ---------------------------------------------------------------------------
def _setting(key, default):
    try:
        val = ADDON.getSetting(key)
    except Exception:
        val = ""
    return val if val else default


def _setting_bool(key, default=False):
    try:
        return ADDON.getSettingBool(key)
    except Exception:
        return default


def target_addon_id():
    return _setting("target_addon_id", DEFAULT_TARGET_ID)


def intercept_enabled():
    """Abrir el selector al entrar en el addon objetivo."""
    return _setting_bool("intercept_target")


def intercept_only_pending():
    """Preguntar solo si el perfil activo no tiene sesion."""
    return _setting_bool("intercept_only_pending")


def purge_cache_enabled():
    """Vaciar la cache del addon objetivo al cambiar de perfil."""
    return _setting_bool("purge_target_cache", True)


def cache_db_name():
    return _setting("cache_db_name", DEFAULT_CACHE_DB)



def txt(string_id, fallback=""):
    """Cadena traducida del addon, con texto de reserva si no hay .po."""
    try:
        return ADDON.getLocalizedString(string_id) or fallback
    except Exception:
        return fallback


def keys():
    return {
        "access": _setting("access_key", DEFAULT_KEYS["access"]),
        "refresh": _setting("refresh_key", DEFAULT_KEYS["refresh"]),
        "slug": _setting("slug_key", DEFAULT_KEYS["slug"]),
        "expires": _setting("expires_key", DEFAULT_KEYS["expires"]),
    }


def token_caducado(user):
    """True si la sesion de ese perfil ya no vale por fecha.

    La fecha se guarda en `expires` desde siempre, pero no se comparaba con
    nada: un perfil con el token muerto se pintaba igual que uno sano. El
    18/9 eso tuvo a Julio un buen rato sin poder entrar en Trakt y sin saber
    por que, porque el perfil salia verde y llevaba una semana caducado.

    Sin token no es caducado, es pendiente. Y una fecha que no se entiende
    no se da por caducada: mejor no decir nada que asustar sin motivo.
    """
    if not (user.get("access") or ""):
        return False
    try:
        cuando = float(user.get("expires") or "")
    except (TypeError, ValueError):
        return False
    return cuando <= time.time()


def marcar_relanzado():
    """Deja dicho que la proxima entrada en el objetivo la provocamos aqui.

    El vigilante no puede distinguir por la ruta si el addon objetivo lo ha
    abierto el usuario o lo hemos relanzado nosotros al elegir perfil, y sin
    distinguirlo se entra en bucle: relanzas, lo ve como entrada, abre el
    selector, que relanza otra vez. Antes se tapaba callando unos segundos,
    pero eso se tragaba tambien las entradas de verdad del usuario si volvia
    rapido. Marcarlo es exacto y no depende del reloj.
    """
    try:
        xbmcgui.Window(HOME_WINDOW).setProperty(RELAUNCH_PROP, str(time.time()))
    except Exception as e:
        log(f"marcar_relanzado() error: {e}")


def consumir_relanzado(caducidad=60.0):
    """True si la entrada que se acaba de ver la provocamos nosotros.

    Se consume: solo vale para una entrada. Y caduca, porque si el usuario
    cierra el objetivo antes de que Kodi llegue a pintarlo, la marca se
    quedaria puesta esperando a una entrada que ya no viene.
    """
    try:
        ventana = xbmcgui.Window(HOME_WINDOW)
        marca = ventana.getProperty(RELAUNCH_PROP)
        if not marca:
            return False
        ventana.clearProperty(RELAUNCH_PROP)
        return (time.time() - float(marca)) < caducidad
    except Exception as e:
        log(f"consumir_relanzado() error: {e}")
        return False


def perfil_de_reserva(db):
    """A que perfil volver cuando el activo se ha quedado sin enlazar.

    Primero el que estaba puesto antes, que es de quien era la sesion que
    se dejo a medias. Si ese ya no esta o tampoco tiene token, cualquiera
    que si lo tenga. Y si no hay ninguno, None: mas vale quedarse con el
    pendiente que dejar a Palantir sin sesion ninguna.
    """
    usuarios = db.get("users", {})
    activo = db.get("active_user")

    anterior = db.get("previous_user")
    if anterior and anterior != activo:
        user = usuarios.get(anterior)
        if user and user.get("access"):
            return anterior

    for uid, user in usuarios.items():
        if uid != activo and user.get("access"):
            return uid
    return None


def get_target():
    """Devuelve el addon objetivo (Palantir) o None si no esta instalado."""
    try:
        return xbmcaddon.Addon(target_addon_id())
    except Exception as e:
        log(f"No se pudo abrir el addon objetivo '{target_addon_id()}': {e}")
        return None


# ---------------------------------------------------------------------------
# Base de datos local (users.json)
# ---------------------------------------------------------------------------
def profile_path():
    path = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
    return path


def db_path():
    return profile_path() + "users.json"


def _empty_db():
    return {"active_user": None, "previous_user": None,
            "users": {}, "remember": False}


def _quarantine(path, reason):
    """Aparta un users.json ilegible en vez de borrarlo en silencio.

    Perder todos los perfiles sin dejar rastro es peor que cualquier error:
    se guarda una copia con marca de tiempo y se avisa al usuario.
    """
    stamp = time.strftime("%Y%m%d-%H%M%S")
    dest = f"{path}.corrupt-{stamp}"

    # Dos corrupciones en el mismo segundo no deben pisarse la copia.
    n = 1
    while xbmcvfs.exists(dest):
        dest = f"{path}.corrupt-{stamp}-{n}"
        n += 1

    try:
        xbmcvfs.copy(path, dest)
        xbmcvfs.delete(path)
        log(f"_quarantine() {reason} -> copia en {dest}")
        notify("MultiUser", "users.json ilegible; se ha guardado una copia")
    except Exception as e:
        log(f"_quarantine() error apartando {path}: {e}")


def load_db():
    path = db_path()

    if not xbmcvfs.exists(path):
        db = _empty_db()
        save_db(db)
        return db

    f = xbmcvfs.File(path)
    try:
        data = f.read()
    finally:
        f.close()

    if not data.strip():
        db = _empty_db()
        save_db(db)
        return db

    try:
        db = json.loads(data)
    except Exception as e:
        _quarantine(path, f"JSON invalido ({e})")
        db = _empty_db()
        save_db(db)
        return db

    # Estructura minima, por si el fichero se edito a mano.
    if not isinstance(db, dict) or not isinstance(db.get("users"), dict):
        _quarantine(path, "estructura invalida")
        db = _empty_db()
        save_db(db)
        return db

    db.setdefault("active_user", None)
    # "No preguntar al entrar en el addon objetivo". Vive aqui y no en los
    # ajustes del addon a proposito: el vigilante corre en el proceso del
    # servicio y relee este fichero del disco en cada comprobacion, asi que
    # el cambio le llega en el acto. Un ajuste escrito desde la ventana
    # podria quedarse en su proceso hasta que Kodi lo recargue, y una
    # casilla que se ve marcada y no hace nada es peor que no tenerla.
    db.setdefault("remember", False)
    # A quien volver si el perfil activo se queda sin enlazar. Se apunta al
    # cambiar de perfil, no se adivina despues: con varios perfiles con
    # sesion, elegir "uno cualquiera" acabaria metiendote en el de otro.
    db.setdefault("previous_user", None)
    # Si el historial de visto ya esta repartido por perfiles. Mientras sea
    # False, lo que haya en watched.db es de todos mezclado y no se guarda
    # en la mochila de nadie. Ver cambiar_watched().
    db.setdefault("watched_aislado", False)
    return db


def save_db(db):
    """Escritura atomica: primero al temporal, luego swap.

    Si se corta la luz a mitad de escritura, el users.json anterior queda
    intacto en vez de convertirse en un JSON truncado que load_db() daria
    por corrupto.
    """
    path = db_path()
    tmp = path + ".tmp"

    f = xbmcvfs.File(tmp, "w")
    try:
        f.write(json.dumps(db, indent=2))
    finally:
        f.close()

    # os.replace es atomico y sobrescribe, en Windows y en POSIX. El perfil
    # del addon siempre es una ruta local, asi que se puede usar os directo.
    os.replace(tmp, path)


def update_db(mutator):
    """Aplica un cambio sobre la version mas reciente del disco.

    La ventana mantiene su copia del db viva mientras esta abierta, y el
    vigilante de service.py escribe cada pocos segundos. Guardar la copia
    de la ventana tal cual pisaria los tokens capturados entre medias, asi
    que toda escritura relee primero.

    `mutator` recibe el db fresco y devuelve True si hay que guardarlo.
    Devuelve el db resultante, para que el llamante refresque su copia.
    """
    db = load_db()
    if mutator(db):
        save_db(db)
    return db


# ---------------------------------------------------------------------------
# Inyeccion / captura de tokens en el addon objetivo
# ---------------------------------------------------------------------------
def inject(uid, db):
    """Carga los tokens del usuario `uid` en los ajustes de Palantir."""
    target = get_target()
    if target is None:
        notify("MultiUser", "El addon objetivo no esta instalado")
        return

    user = db["users"][uid]
    k = keys()

    anterior = target.getSetting(k["access"])

    target.setSetting(k["access"], user.get("access", ""))
    target.setSetting(k["refresh"], user.get("refresh", ""))
    target.setSetting(k["slug"], user.get("slug", ""))
    target.setSetting(k["expires"], user.get("expires", ""))

    log(f"inject() uid={uid} access_len={len(user.get('access',''))} "
        f"slug={user.get('slug','')} expires={user.get('expires','')}")

    # Sin esto el addon objetivo sigue mostrando las listas cacheadas del
    # perfil anterior hasta que caduquen. Pero solo si de verdad cambia de
    # perfil: al volver a elegir el que ya estaba, sus listas siguen siendo
    # suyas y vaciarlas le obliga a pedirselo todo otra vez a Trakt. Unas
    # cuantas veces seguidas y Trakt responde 403 por exceso de peticiones,
    # que fue lo que paso probando la tarde del 9/9.
    if anterior != user.get("access", ""):
        purge_target_cache()
    else:
        log("inject() el perfil ya estaba puesto: no se vacia la cache")


def target_profile_path():
    """Carpeta de datos del addon objetivo. None si no esta instalado."""
    target = get_target()
    if target is None:
        return None
    return xbmcvfs.translatePath(target.getAddonInfo("profile"))


def purge_target_cache():
    """Vacia la cache de listados del addon objetivo.

    Palantir cachea el resultado de las listas de Trakt con una clave que no
    incluye la cuenta: al cambiar de perfil sigue sirviendo lo del anterior
    hasta que caduque, y salen listas que no son de ese usuario.

    Vaciarla no pierde nada suyo. Es cache con caducidad, el propio addon la
    tira sola cada pocos minutos; lo unico que cuesta es que la primera carga
    tras cambiar de perfil va mas lenta.

    Se vacia SOLO esa tabla. Ni se borra el fichero ni se tocan las demas,
    para no llevarse por delante nada que el addon objetivo guarde ahi
    (el historial de visto, por ejemplo, vive en otro sitio).
    """
    if not purge_cache_enabled():
        return False

    base = target_profile_path()
    if not base:
        return False

    path = os.path.join(base, cache_db_name())
    if not xbmcvfs.exists(path):
        log(f"purge_target_cache() no existe {path}")
        return False

    try:
        # timeout por si el addon objetivo tiene la base abierta ahora mismo
        con = sqlite3.connect(path, timeout=2.0)
        try:
            tablas = [r[0] for r in con.execute(
                "SELECT name FROM sqlite_master WHERE type='table'")]
            if CACHE_TABLE not in tablas:
                log(f"purge_target_cache() no hay tabla '{CACHE_TABLE}' "
                    f"en {path} (hay: {tablas})")
                return False

            n = con.execute(f"SELECT COUNT(*) FROM {CACHE_TABLE}").fetchone()[0]
            con.execute(f"DELETE FROM {CACHE_TABLE}")
            con.commit()
        finally:
            con.close()

        log(f"purge_target_cache() {n} filas borradas de {path}")
        return True
    except Exception as e:
        # Que la cache no se deje vaciar no puede impedir el cambio de perfil.
        log(f"purge_target_cache() error: {e}")
        return False


# ---------------------------------------------------------------------------
# Historial de visto (watched.db del addon objetivo)
# ---------------------------------------------------------------------------
# Palantir apunta en watched.db lo que se ha visto, y lo apunta en un unico
# monton: ni episodes_watched ni movies_watched ni shows_watched llevan
# columna de cuenta. Con dos perfiles en el mismo Kodi eso significa que lo
# que ve uno sale marcado en el otro: series que empezo tu hermano te
# aparecen a medias, y las que ya te habias visto vuelven a salir sin
# empezar. Vaciar cache.db no lo arregla, porque eso son los listados; esto
# es otra base distinta.
#
# last_activities_trakt es la que lo vuelve permanente, y por eso viaja con
# las demas. Ahi guarda Palantir la fecha de lo ultimo que se bajo de Trakt,
# y solo vuelve a pedir el historial si Trakt trae algo mas nuevo. Despues
# de cambiar de perfil esas fechas son las del otro, asi que si tu cuenta
# tiene actividad mas antigua Palantir concluye que no hay nada nuevo y se
# queda con el monton mezclado para siempre.
#
# listas_trakt NO esta en la lista a proposito: esa si lleva columna `user`
# y las dos cuentas conviven bien. views y CERTIFICATE son del mando y del
# aparato, no de quien mira.
WATCHED_DB = "watched.db"
WATCHED_TABLES = ("episodes_watched", "movies_watched", "shows_watched",
                  "favorites", "last_activities_trakt")

# La de las fechas se trata aparte: NO se puede dejar vacia. Palantir la lee
# esperando encontrar sus claves y, si no estan, se rompe con un KeyError
# ('movies' en el log del 18/9) y no sincroniza nada de nada: ni vistos, ni
# favoritos, ni la ventana de elegir listas. Con las filas puestas y la
# fecha en la prehistoria ve que todo esta viejo y se lo baja entero, que es
# justo lo que se busca.
ACTIVIDADES = "last_activities_trakt"
EPOCA = "1970-01-01T00:00:00.000Z"
# Las que Palantir tenia puestas cuando funcionaba. Solo se usan como
# semilla si falta alguna; las que ya esten se respetan, porque el juego de
# claves es suyo y puede cambiar entre versiones.
SEMILLA_ACTIVIDADES = (
    ("lists", "updated_at"),
    ("shows", "watchlisted_at"),
    ("movies", "watchlisted_at"),
    ("episodes", "watched_at"),
    ("episodes", "paused_at"),
    ("movies", "watched_at"),
    ("movies", "paused_at"),
)


def isolate_watched_enabled():
    """Dar a cada perfil su propio historial de visto."""
    return _setting_bool("isolate_watched", True)


def watched_db_name():
    return _setting("watched_db_name", WATCHED_DB)


def watched_db_path():
    """Ruta de watched.db, o None si el objetivo no esta o aun no la ha creado."""
    base = target_profile_path()
    if not base:
        return None
    path = os.path.join(base, watched_db_name())
    return path if xbmcvfs.exists(path) else None


def mochila_dir():
    """Donde guardamos el historial de cada perfil, dentro de lo nuestro.

    En nuestra carpeta y no en la de Palantir: si algun dia se desinstala o
    se le vacian los datos, los historiales guardados no se van con el.
    """
    path = os.path.join(profile_path(), "watched")
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
    return path


def mochila_path(uid):
    return os.path.join(mochila_dir(), f"{uid}.db")


def _tablas_de_cuenta(con, esquema="main"):
    """Las de WATCHED_TABLES que existen de verdad en ese esquema.

    Se comprueba en vez de darlas por hechas: Palantir crea cada tabla
    cuando le hace falta, y una version suya distinta puede no tenerlas
    todas. Mejor mover las que haya que reventar en la primera que falte.
    """
    hay = {row[0] for row in con.execute(
        f"SELECT name FROM {esquema}.sqlite_master WHERE type='table'")}
    return [t for t in WATCHED_TABLES if t in hay]


def _columnas(con, esquema, tabla):
    return [row[1] for row in con.execute(
        f"PRAGMA {esquema}.table_info('{tabla}')")]


# La tabla de listas si lleva columna `user`, asi que Palantir sabe de quien
# es cada una. Lo que no se puede dar por hecho es que lo mire al pintarlas.
# Dejando en ella solo las del perfil que entra, que salgan las del otro es
# imposible, filtre Palantir o no.
LISTAS = "listas_trakt"
# Y lo que se quita no se pierde: va antes a un respaldo aparte, en nuestra
# carpeta. Es la red que falto el 18/9, cuando un borrado mio se llevo las
# listas elegidas de dos cuentas y no habia de donde sacarlas.
RESPALDO_LISTAS = "listas-respaldo.db"


def respaldo_listas_path():
    return os.path.join(mochila_dir(), RESPALDO_LISTAS)


def _respaldar_listas(con):
    """Copia listas_trakt al respaldo y devuelve sus columnas.

    Engancha el respaldo a la conexion como 'respaldo'. Nada que salga de
    listas_trakt debe salir sin pasar antes por aqui.
    """
    con.execute("ATTACH DATABASE ? AS respaldo", (respaldo_listas_path(),))
    cols = ", ".join(_columnas(con, "main", LISTAS))
    con.execute(f"CREATE TABLE IF NOT EXISTS respaldo.{LISTAS} AS "
                f"SELECT * FROM main.{LISTAS} WHERE 0")

    # Se refresca lo de las cuentas que estan ahora en la tabla y se respeta
    # lo de las que no, que sigue guardado de antes.
    con.execute(f"DELETE FROM respaldo.{LISTAS} WHERE user IN "
                f"(SELECT user FROM main.{LISTAS})")
    con.execute(f"INSERT INTO respaldo.{LISTAS} ({cols}) "
                f"SELECT {cols} FROM main.{LISTAS}")
    return cols


def ajustar_listas(slug):
    """Deja en listas_trakt solo las listas de esa cuenta, respaldando antes.

    Al perfil que entra se le devuelve ademas lo suyo que hubiera en el
    respaldo, por si un cambio anterior se lo quito.
    """
    if not watched_db_path():
        return False

    try:
        con = sqlite3.connect(watched_db_path(), timeout=5.0)
        try:
            hay = {r[0] for r in con.execute(
                "SELECT name FROM sqlite_master WHERE type='table'")}
            if LISTAS not in hay:
                log(f"ajustar_listas() no hay tabla '{LISTAS}'")
                return False

            cols = _respaldar_listas(con)

            # Lo suyo de vuelta, y fuera lo de los demas.
            con.execute(f"INSERT OR REPLACE INTO main.{LISTAS} ({cols}) "
                        f"SELECT {cols} FROM respaldo.{LISTAS} WHERE user = ?",
                        (slug,))
            fuera = con.execute(f"DELETE FROM main.{LISTAS} WHERE user <> ?",
                                (slug,)).rowcount
            con.commit()
            mias = con.execute(f"SELECT COUNT(*) FROM main.{LISTAS}").fetchone()[0]
        finally:
            con.close()
        log(f"ajustar_listas() slug={slug} suyas={mias} apartadas={fuera}")
        return True
    except Exception as e:
        log(f"ajustar_listas() error: {e}")
        return False


def _reiniciar_actividades(con):
    """Atrasa a la prehistoria las fechas de sincronizacion, sin quitar filas.

    Conserva las claves que haya (son de Palantir, y pueden cambiar entre
    versiones suyas) y siembra las que falten. Ver el comentario de
    ACTIVIDADES: vaciar esta tabla rompe el addon objetivo.
    """
    con.execute(f"UPDATE main.{ACTIVIDADES} SET date = ?", (EPOCA,))
    for tipo, accion in SEMILLA_ACTIVIDADES:
        con.execute(
            f"INSERT OR IGNORE INTO main.{ACTIVIDADES} (type, action, date) "
            f"VALUES (?, ?, ?)", (tipo, accion, EPOCA))


def _abrir_watched(uid):
    """watched.db con la mochila de `uid` enganchada al lado, como 'bolsa'.

    Con las dos bases abiertas a la vez el trasvase es un INSERT ... SELECT
    dentro de una transaccion, sin pasar por Python ni por ficheros
    intermedios. ATTACH crea la mochila si es la primera vez.
    """
    con = sqlite3.connect(watched_db_path(), timeout=5.0)
    con.execute("ATTACH DATABASE ? AS bolsa", (mochila_path(uid),))
    return con


def guardar_watched(uid):
    """Vuelca a la mochila de `uid` lo que hay ahora mismo en watched.db.

    Se llama justo antes de cambiar de perfil, que es el ultimo momento en
    que lo que hay en watched.db es suyo entero.
    """
    if not isolate_watched_enabled() or not uid or not watched_db_path():
        return False

    try:
        con = _abrir_watched(uid)
        try:
            tablas = _tablas_de_cuenta(con)
            for t in tablas:
                con.execute(f"DROP TABLE IF EXISTS bolsa.{t}")
                con.execute(f"CREATE TABLE bolsa.{t} AS SELECT * FROM main.{t}")
            con.commit()
        finally:
            con.close()
        log(f"guardar_watched() uid={uid} tablas={len(tablas)}")
        return True
    except Exception as e:
        # Igual que con la cache: que esto falle no puede dejar al usuario
        # sin poder cambiar de perfil.
        log(f"guardar_watched() error: {e}")
        return False


def cargar_watched(uid):
    """Deja en watched.db el historial de `uid`, y solo el suyo.

    Si el perfil no tiene mochila (primera vez que entra) las tablas se
    quedan vacias: Palantir ve que no sabe nada de esa cuenta y se baja el
    historial de Trakt entero. Eso pasa una vez por perfil y no en cada
    cambio, que es justo lo que evita el 403 por exceso de peticiones.

    Con una excepcion: la tabla de fechas nunca se queda vacia, se atrasa.
    Ver el comentario de ACTIVIDADES.
    """
    if not isolate_watched_enabled() or not watched_db_path():
        return False

    try:
        con = _abrir_watched(uid)
        try:
            en_bolsa = _tablas_de_cuenta(con, "bolsa")
            restauradas = 0
            for t in _tablas_de_cuenta(con):
                # Quien no tiene nada guardado de esta tabla se queda con
                # ella vacia... menos la de las fechas, que vaciada rompe a
                # Palantir. Esa se atrasa en vez de vaciarse.
                if t == ACTIVIDADES and t not in en_bolsa:
                    _reiniciar_actividades(con)
                    continue
                con.execute(f"DELETE FROM main.{t}")
                if t not in en_bolsa:
                    continue
                # Por columnas comunes y no "SELECT *": si Palantir se
                # actualiza y le anade una columna a la tabla, la mochila
                # guardada con la version anterior sigue sirviendo.
                comunes = [c for c in _columnas(con, "main", t)
                           if c in _columnas(con, "bolsa", t)]
                if not comunes:
                    continue
                cols = ", ".join(comunes)
                # OR REPLACE y no INSERT a secas: la mochila se crea con un
                # CREATE TABLE ... AS SELECT, que copia las filas pero NO la
                # clave primaria. Si en ella se colara una fila repetida, un
                # INSERT normal reventaria contra la clave de Palantir y se
                # perderia la restauracion entera.
                con.execute(f"INSERT OR REPLACE INTO main.{t} ({cols}) "
                            f"SELECT {cols} FROM bolsa.{t}")
                restauradas += 1

            # Ultima red: una mochila guardada cuando la tabla de fechas ya
            # estaba vacia la dejaria vacia otra vez al restaurarla, y con
            # eso Palantir se rompe. Si ha quedado sin filas, se siembra.
            if ACTIVIDADES in _tablas_de_cuenta(con):
                vacia = not con.execute(
                    f"SELECT 1 FROM main.{ACTIVIDADES} LIMIT 1").fetchone()
                if vacia:
                    log("cargar_watched() la tabla de fechas venia vacia, "
                        "se siembra para no romper al objetivo")
                    _reiniciar_actividades(con)
            con.commit()
        finally:
            con.close()
        log(f"cargar_watched() uid={uid} restauradas={restauradas}")
        return True
    except Exception as e:
        log(f"cargar_watched() error: {e}")
        return False


def _hay_vistos():
    """True si watched.db tiene ya algo visto de la cuenta que esta puesta."""
    try:
        con = sqlite3.connect(watched_db_path(), timeout=5.0)
        try:
            for t in ("episodes_watched", "movies_watched"):
                if t not in _tablas_de_cuenta(con):
                    continue
                if con.execute(f"SELECT 1 FROM main.{t} LIMIT 1").fetchone():
                    return True
            return False
        finally:
            con.close()
    except Exception as e:
        log(f"_hay_vistos() error: {e}")
        return True     # ante la duda, no se da por estrenado


def estreno_pendiente(db):
    """Datos del perfil que esta esperando su primera sincronizacion."""
    dato = db.get("estreno")
    return dato if isinstance(dato, dict) and dato.get("uid") else None


def _marcar_estreno(uid):
    """Apunta que este perfil entra sin historial y le toca bajarselo entero.

    Mientras dura esa descarga, Palantir monta sus listados y los cachea 24
    horas. Si le pilla a medias, se queda una foto diciendo que no has visto
    nada, y eso es justo lo contrario de para lo que sirve Trakt. Apuntarlo
    aqui permite al servicio vaciar esa cache en cuanto la descarga termine.
    """
    def mutator(db):
        db["estreno"] = {"uid": uid, "desde": time.time()}
        return True
    update_db(mutator)
    log(f"_marcar_estreno() uid={uid}: se vigilara el fin de la sincronizacion")


def _olvidar_estreno():
    def mutator(db):
        if "estreno" not in db:
            return False
        del db["estreno"]
        return True
    update_db(mutator)


def sincronizacion_acabada():
    """True si Palantir ya ha puesto fechas de verdad donde habia 1970.

    Es la senal que se vio el 18/9: mientras baja el historial las fechas
    siguen en la prehistoria, y al terminar las escribe todas con la fecha
    real de la cuenta.
    """
    try:
        con = sqlite3.connect(f"file:{watched_db_path()}?mode=ro", uri=True)
        try:
            if ACTIVIDADES not in _tablas_de_cuenta(con):
                return True
            quedan = con.execute(
                f"SELECT COUNT(*) FROM {ACTIVIDADES} WHERE date = ?",
                (EPOCA,)).fetchone()[0]
            return quedan == 0
        finally:
            con.close()
    except Exception as e:
        log(f"sincronizacion_acabada() error: {e}")
        return False


def atender_estreno(db, espera_maxima=600.0):
    """Vacia los listados cacheados en cuanto acaba la primera sincronizacion.

    Lo llama el servicio en cada vuelta. Sin esto, el primer perfil que
    estrena se queda hasta 24 horas con las series marcadas como sin ver,
    porque Palantir cacheo el listado mientras aun se estaba bajando el
    historial (visto el 18/9: cacheado a las 19:15:35, descarga terminada a
    las 19:15:36).

    Devuelve True si se ha vaciado la cache.
    """
    if not isolate_watched_enabled() or not watched_db_path():
        return False

    estreno = estreno_pendiente(db)
    if not estreno:
        return False

    # Se rinde por tiempo: una cuenta sin nada visto en Trakt podria no
    # llegar a escribir nunca alguna de esas fechas, y no vamos a quedarnos
    # mirando para siempre.
    if time.time() - float(estreno.get("desde", 0)) > espera_maxima:
        log("atender_estreno() se acabo la espera, se deja de vigilar")
        _olvidar_estreno()
        return False

    if not sincronizacion_acabada():
        return False

    log(f"atender_estreno() uid={estreno['uid']}: sincronizacion terminada, "
        f"se vacian los listados cacheados a medias")
    purge_target_cache()
    _olvidar_estreno()
    return True


def _marcar_aislado():
    def mutator(db):
        db["watched_aislado"] = True
        return True
    update_db(mutator)


def cambiar_watched(saliente, entrante):
    """Guarda el historial del perfil que sale y pone el del que entra."""
    if not isolate_watched_enabled():
        return False
    if not watched_db_path():
        log("cambiar_watched() el objetivo todavia no tiene watched.db")
        return False

    primera = not load_db().get("watched_aislado")

    # Reelegir el perfil que ya estaba no toca nada... salvo la primera vez.
    # Si no, con un solo perfil de por medio la limpieza inicial no llegaria
    # a hacerse nunca: se entra siempre como el activo, no hay cambio, y el
    # monton mezclado se queda ahi para siempre.
    if saliente == entrante and not primera:
        log("cambiar_watched() el perfil ya estaba puesto: no se toca nada")
        return False

    if primera:
        # Lo que hay en watched.db es de todos los perfiles mezclado, de
        # antes de que esto existiera. Guardarlo le colgaria a uno el
        # historial del otro para siempre, asi que se tira: cada cual se
        # baja el suyo limpio de Trakt la primera vez que entre.
        log("cambiar_watched() primera vez: lo que hay es de todos y se tira")
        _marcar_aislado()
    else:
        guardar_watched(saliente)

    cargar_watched(entrante)

    # Y que en el menu no quede rastro de las listas del anterior.
    usuario = load_db().get("users", {}).get(entrante, {})
    ajustar_listas(usuario.get("slug", "") or "")

    # Si entra sin historial, le toca bajarselo entero: hay que estar
    # pendiente de cuando acabe para vaciar los listados que Palantir cachee
    # mientras tanto. Ver _marcar_estreno().
    if not _hay_vistos():
        _marcar_estreno(entrante)
    else:
        # Y si entra con lo suyo puesto no hay nada que esperar. Se limpia
        # por si quedo un apunte de un perfil anterior que estreno y se
        # cambio de perfil antes de que terminara: si no, el aviso llegaria
        # tarde y a nombre de quien no es.
        _olvidar_estreno()
    return True


def borrar_listas(slug):
    """Quita de listas_trakt lo que se eligiera para esa cuenta de Trakt.

    Esa tabla si lleva columna `user`, asi que se borra solo lo suyo y las
    demas cuentas se quedan como estaban.
    """
    if not slug or not watched_db_path():
        return False

    try:
        con = sqlite3.connect(watched_db_path(), timeout=5.0)
        try:
            tablas = [r[0] for r in con.execute(
                "SELECT name FROM sqlite_master WHERE type='table'")]
            if LISTAS not in tablas:
                log(f"borrar_listas() no hay tabla '{LISTAS}'")
                return False
            # Al respaldo antes de quitarlas: esto se llama al desvincular
            # una cuenta, y el 18/9 se llevo por delante las listas elegidas
            # de dos cuentas sin dejar copia de nada.
            _respaldar_listas(con)
            n = con.execute(f"DELETE FROM main.{LISTAS} WHERE user = ?",
                            (slug,)).rowcount
            con.commit()
        finally:
            con.close()
        log(f"borrar_listas() slug={slug} filas={n}")
        return True
    except Exception as e:
        log(f"borrar_listas() error: {e}")
        return False


def olvidar_cuenta(uid, slug="", activo=False):
    """Borra el rastro local de una cuenta al desvincularla.

    Limpiar el token es empezar de cero con esa cuenta, y eso tiene que
    incluir lo que Palantir guarde suyo. Sobre todo la fecha de la ultima
    sincronizacion: la ventana de elegir que listas se añaden sale SOLO al
    iniciar sesion, y si Palantir se encuentra una fecha ya puesta decide
    que no hay listas nuevas y no la saca. Volver a vincular la cuenta no
    serviria de nada. Visto el 18/9 con el perfil de Daniel.
    """
    borrar_mochila(uid)
    borrar_listas(slug)
    if activo:
        # Es el que esta puesto ahora mismo en Palantir, asi que su rastro
        # no esta en ninguna mochila sino en el propio watched.db. Sin
        # mochila que restaurar, esto lo deja en blanco.
        cargar_watched(uid)
    return True


def borrar_mochila(uid):
    """Tira el historial guardado de un perfil que ya no existe."""
    try:
        path = mochila_path(uid)
        if xbmcvfs.exists(path):
            xbmcvfs.delete(path)
            log(f"borrar_mochila() uid={uid}")
            return True
    except Exception as e:
        log(f"borrar_mochila() error: {e}")
    return False


def clear_trakt_session():
    """Vacia los tokens de Trakt en el addon objetivo."""
    target = get_target()
    if target is None:
        return
    k = keys()
    target.setSetting(k["access"], "")
    target.setSetting(k["refresh"], "")
    target.setSetting(k["slug"], "")
    target.setSetting(k["expires"], "")
    log("clear_trakt_session() done")


def read_target_tokens():
    """Lee los tokens actuales del addon objetivo. None si no esta instalado."""
    target = get_target()
    if target is None:
        return None
    k = keys()
    return {
        "access": target.getSetting(k["access"]),
        "refresh": target.getSetting(k["refresh"]),
        "slug": target.getSetting(k["slug"]),
        "expires": target.getSetting(k["expires"]),
    }


def capture_from_target(uid, db):
    """Copia el token actual de Palantir al usuario `uid`.

    Devuelve True solo si habia un token nuevo (distinto y no vacio) que
    realmente se ha guardado. Nunca sobreescribe con vacio.
    """
    tokens = read_target_tokens()
    if tokens is None:
        return False

    new_access = tokens.get("access") or ""
    if not new_access:
        return False  # Palantir no tiene sesion -> nada que capturar

    # Un token que ya es de OTRO perfil no se adopta. Si aparece aqui es que
    # Palantir sigue con la sesion anterior cargada, no que este usuario se
    # haya logueado: adoptarlo dejaria dos perfiles con la misma cuenta.
    for other_uid, other in db.get("users", {}).items():
        if other_uid != uid and (other.get("access") or "") == new_access:
            log(f"capture_from_target() el token ya es de uid={other_uid}, "
                f"no se copia a uid={uid}")
            return False

    user = db["users"][uid]
    if (user.get("access") or "") == new_access:
        # Mismo token, pero el slug puede llegar tarde: Palantir lo escribe
        # un instante despues que el access, y si capturamos justo en medio
        # nos quedamos con el vacio PARA SIEMPRE, porque aqui solo se compara
        # el access. Y un perfil sin slug hace que Palantir no sepa que
        # listas son suyas.
        late_slug = tokens.get("slug") or ""
        if late_slug and not (user.get("slug") or ""):
            user["slug"] = late_slug
            user["refresh"] = user.get("refresh") or tokens.get("refresh") or ""
            user["expires"] = user.get("expires") or tokens.get("expires") or ""
            log(f"capture_from_target() slug tardio '{late_slug}' para uid={uid}")
            return True
        return False  # ya lo teniamos

    user["access"] = new_access
    user["refresh"] = tokens.get("refresh") or ""
    user["slug"] = tokens.get("slug") or ""
    user["expires"] = tokens.get("expires") or ""
    log(f"capture_from_target() token guardado para uid={uid}")
    return True


def reconcile_active(db):
    """Auto-captura: si Palantir tiene un token nuevo para el usuario activo,
    lo guarda en users.json. Cubre tanto el alta inicial (vacio -> token)
    como el refresco de Trakt (token viejo -> token nuevo).

    Devuelve el nombre del usuario si se ha guardado algo, si no None.
    """
    active = db.get("active_user")
    if not active or active not in db.get("users", {}):
        return None

    if capture_from_target(active, db):
        save_db(db)
        return db["users"][active].get("name", active)
    return None


def launch_target():
    """Abre el addon objetivo, que se relanza y relee los ajustes del disco.

    Un plugin de Kodi no es un proceso vivo: se invoca, construye el listado
    y muere. Con esto basta para que el objetivo arranque de nuevo y lea el
    token recien inyectado; comprobado en el log, Kodi lo vuelve a invocar.

    Nada de refrescar el contenedor desde aqui: esto corre en el onClick de
    la ventana, con el modal a medio cerrar, y ahi un Container.Refresh
    cierra Kodi.
    """
    target_id = target_addon_id()
    root = f"plugin://{target_id}/"
    marcar_relanzado()
    log(f"launch_target() -> ActivateWindow({VIDEO_WINDOW}, {root})")
    xbmc.executebuiltin(f'ActivateWindow({VIDEO_WINDOW},"{root}",return)')
