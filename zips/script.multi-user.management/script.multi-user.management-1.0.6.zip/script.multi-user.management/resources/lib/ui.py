# -*- coding: utf-8 -*-
import os
import random
import time
import xbmc
import xbmcgui
import xbmcvfs
from . import manager

# Carpeta de iconos resuelta desde la instalacion real del addon, para no
# depender de que el id sea siempre "script.multi-user.management".
ICONS_DIR = os.path.join(
    xbmcvfs.translatePath(manager.ADDON.getAddonInfo("path")),
    "resources", "skins", "default", "media", "icons",
)


AVATARS_DIR = os.path.join(
    xbmcvfs.translatePath(manager.ADDON.getAddonInfo("path")),
    "resources", "skins", "default", "media", "avatars",
)


def _art(name):
    """Par icon/thumb de un icono (version normal y con foco)."""
    return {
        "icon": os.path.join(ICONS_DIR, f"{name}.png"),
        "thumb": os.path.join(ICONS_DIR, f"{name}_focus.png"),
    }


def avatares():
    """Los avatares que hay en la carpeta, por nombre y sin extension.

    Se leen del disco en vez de tener la lista escrita aqui: asi anadir uno
    es soltar el png en la carpeta, sin tocar codigo.
    """
    try:
        return sorted(f[:-4] for f in os.listdir(AVATARS_DIR)
                      if f.lower().endswith(".png"))
    except Exception as e:
        manager.log(f"avatares() no se pudo leer {AVATARS_DIR}: {e}")
        return []


def _art_perfil(user):
    """El avatar del perfil, o el icono generico si no tiene o falta.

    En el db se guarda solo el nombre, no la ruta: si el addon cambia de
    sitio o se reinstala, los avatares siguen encontrandose. Y si alguien
    borra un png, el perfil no se queda sin cara.
    """
    nombre = user.get("avatar") or ""
    if nombre:
        ruta = os.path.join(AVATARS_DIR, f"{nombre}.png")
        if os.path.exists(ruta):
            # El mismo para las dos, que el foco ya se nota por el marco.
            return {"icon": ruta, "thumb": ruta}
    return _art("user")


def avatar_libre(db, disponibles=None):
    """Un avatar al azar de los que no tenga nadie.

    Al azar y no por orden para que dos perfiles creados seguidos no salgan
    con colores vecinos. Si hay mas perfiles que avatares se repite el menos
    usado, que es mejor que dejar a alguien sin cara.
    """
    disponibles = avatares() if disponibles is None else disponibles
    if not disponibles:
        return ""

    usados = [u.get("avatar") for u in db.get("users", {}).values()]
    libres = [a for a in disponibles if a not in usados]
    if libres:
        return random.choice(libres)
    return min(disponibles, key=usados.count)

# La ventana se abre una vez y no se cierra para volver a abrirse: el
# servicio la lanza en su propio hilo con doModal(), y encadenar dos
# modales deja a Kodi sin devolver el control, con el vigilante de
# navegacion muerto hasta reiniciar. Lo que cambie aqui, que cambie sin
# cerrar la ventana.
SKIN_XML = "ProfileSelect.xml"

# Controles del skin: el 100 son las personas (rejilla) y el 200 las
# acciones (fila fija abajo).
LIST_ID = 100
ACTIONS_ID = 200
REMEMBER_ID = 300


def open_selector():
    """Abre el selector. Una ventana, un doModal, y a casa."""
    w = ProfileSelectWindow(
        SKIN_XML,
        manager.ADDON.getAddonInfo("path"),
        "default",
        "1080i",
    )
    abierto = time.time()
    w.doModal()
    # Traza puntual: si se cierra solo, a los pocos decimos, es que algo se
    # lo ha llevado por delante y no ha sido el usuario.
    manager.log(f"selector: cerrado tras {time.time() - abierto:.1f}s "
                f"(motivo={getattr(w, 'motivo_cierre', 'desconocido')})")
    del w


class ProfileSelectWindow(xbmcgui.WindowXML):

    # Margen de gracia contra las pulsaciones que ya venian de camino.
    # Entre que se entra en el addon objetivo y que esta ventana termina de
    # pintarse pasa cerca de un segundo, y en ese rato el usuario sigue con
    # el mando en la mano: un Atras que iba dirigido a otra pantalla se
    # lleva el selector por delante nada mas salir, y parece que no ha
    # salido. Visto en el kodi.log del 9/9: abierto a las 20:21:19 y
    # cerrado un segundo despues con motivo=atras, sin haberlo visto.
    GRACIA = 0.8

    def onInit(self):
        self.db = manager.load_db()
        self.list = self.getControl(LIST_ID)
        self.actions = self.getControl(ACTIONS_ID)
        self.remember = self.getControl(REMEMBER_ID)
        self.context_open = False
        self.abierto_en = time.time()
        self._repartir_avatares()
        self.refresh()

    def refresh(self, mover_foco=True):
        self.list.reset()
        self.actions.reset()

        active = self.db.get("active_user")
        self._set_header(active)
        active_index = 0
        index = 0

        for uid, user in self.db["users"].items():
            has_token = bool(user.get("access"))
            caducado = manager.token_caducado(user)

            # Marca visual: activo, pendiente de vincular y/o caducado. No
            # son excluyentes: el activo sin token es justo el que esta
            # esperando a que se capture la sesion, y el activo caducado es
            # el que parece que funciona y no funciona.
            marcas = []
            if uid == active:
                marcas.append("activo")
            if not has_token:
                marcas.append("pendiente")
            if caducado:
                marcas.append("caducado")

            label = f"{user['name']}  ({', '.join(marcas)})" if marcas else user["name"]

            item = xbmcgui.ListItem(label=label)
            item.setArt(_art_perfil(user))
            item.setProperty("uid", uid)
            # El nombre a secas, para la rejilla: alli el estado lo dice el
            # punto de color, y meter las marcas en el texto no dejaba
            # sitio al nombre. La etiqueta completa se queda para la lista.
            item.setProperty("name", user["name"])
            # Mismo estado que las marcas del texto, pero como clave fija
            # para el skin (la rejilla lo pinta como punto de color). No se
            # saca de `marcas` para que traducir las etiquetas algun dia no
            # rompa en silencio las condiciones del XML.
            #
            # Caducado va PRIMERO, incluso por delante de activo: el 18/9 el
            # perfil activo llevaba una semana con el token muerto y se
            # pintaba verde, que es lo que hizo perder la tarde. Cual es el
            # activo ya lo dice la cabecera; que uno no vaya a funcionar no
            # lo dice nada mas.
            if caducado:
                item.setProperty("state", "caducado")
            elif uid == active:
                item.setProperty("state", "activo")
            elif not has_token:
                item.setProperty("state", "pendiente")
            self.list.addItem(item)

            if uid == active:
                active_index = index
            index += 1

        # Las acciones van en su propia fila, fuera de la rejilla de
        # perfiles: asi las tarjetas de arriba son solo personas y
        # "Añadir Usuario" no cambia de sitio al crear un perfil.
        #
        # La segunda etiqueta es la version corta, para el hueco de 300 de
        # la fila; la larga se queda para los dialogos y el registro.
        acciones = (
            ("__add__", "Añadir Usuario", "Añadir Usuario", "add"),
            ("__capture__", "Capturar sesión actual", "Capturar sesión", "capture"),
            ("__clear__", "Limpiar sesión Trakt", "Limpiar sesión", "clean"),
            ("__back__", "Volver al menú de Kodi", "Volver", "back"),
        )

        for uid, label, corta, icono in acciones:
            item = xbmcgui.ListItem(label=label)
            item.setArt(_art(icono))
            item.setProperty("uid", uid)
            item.setProperty("short", corta)
            self.actions.addItem(item)

        try:
            self.remember.setSelected(bool(self.db.get("remember")))
        except Exception as e:
            manager.log(f"refresh() casilla: {e}")

        # Mejora 6B: situar el cursor sobre el usuario activo al abrir
        try:
            self.list.selectItem(active_index)
        except Exception:
            pass

        # Sin perfiles la rejilla esta vacia y Kodi no puede darle el foco:
        # hay que llevarselo a las acciones o la ventana se queda muerta en
        # el primer arranque, con "Añadir Usuario" a la vista y sin forma
        # de llegar hasta el.
        if mover_foco and not self.db["users"]:
            try:
                self.setFocusId(ACTIONS_ID)
            except Exception as e:
                manager.log(f"refresh() foco: {e}")

    def _recien_abierto(self):
        """True mientras dura el margen de gracia desde que se abrio."""
        return (time.time() - getattr(self, "abierto_en", 0)) < self.GRACIA

    def _repartir_avatares(self):
        """Da avatar a quien no tenga, al azar y sin repetir.

        Cubre dos casos: los perfiles creados antes de que existieran los
        avatares, que salian con el icono gris de siempre, y los que
        apuntan a un png que ya no esta (por ejemplo si se cambia la
        coleccion entera por otra). Los segundos se tratan como si no
        tuvieran, o se quedarian en gris para siempre.
        """
        disponibles = avatares()
        if not disponibles:
            return

        def mutator(db):
            huerfanos = [u for u in db["users"].values()
                         if u.get("avatar") not in disponibles]
            for user in huerfanos:
                user["avatar"] = avatar_libre(db, disponibles)
            return bool(huerfanos)

        self._apply(mutator)

    def _set_header(self, active):
        """Titulo y subtitulo como propiedades, para que los lea el skin.

        Asi el texto vive en el .po y no incrustado en el XML. El diseno
        clasico no las usa: se las come sin enterarse.
        """
        user = self.db["users"].get(active) if active else None
        if user:
            sub = f"{manager.txt(30018, 'Perfil actual')}: {user['name']}"
            # Mientras se enlaza, el perfil activo esta a medias. Decirlo
            # aqui evita la duda de por que el addon objetivo pide vincular.
            if not user.get("access"):
                sub += " — sin sesión"
        else:
            sub = manager.txt(30019, "Ningún perfil activo")

        try:
            self.setProperty("title", manager.txt(30016, "¿Quién está viendo?"))
            self.setProperty("subtitle", sub)
        except Exception as e:
            manager.log(f"_set_header() error: {e}")


    def _toggle_remember(self):
        """Marca o desmarca "no preguntar al entrar en el addon objetivo".

        Con esto puesto, entrar en el objetivo usa el perfil activo sin
        abrir nada; para cambiar de perfil hay que lanzar el addon desde el
        menu de Kodi, que es tambien desde donde se desmarca.
        """
        nuevo = not bool(self.db.get("remember"))

        def mutator(db):
            db["remember"] = nuevo
            return True

        self._apply(mutator)
        manager.log(f"no preguntar al entrar -> {nuevo}")
        # Sin mover el foco: el usuario esta en la casilla y ahi se queda.
        self.refresh(mover_foco=False)

    def _apply(self, mutator):
        """Guarda un cambio releyendo antes el db del disco.

        Evita pisar lo que el vigilante de service.py haya escrito mientras
        esta ventana estaba abierta con su copia en memoria.
        """
        self.db = manager.update_db(mutator)

    def _capture_active(self):
        """Red de seguridad: guarda el token actual del usuario activo."""
        def mutator(db):
            active = db.get("active_user")
            if not active or active not in db["users"]:
                return False
            return manager.capture_from_target(active, db)

        self._apply(mutator)

    def onClick(self, controlId):
        if self._recien_abierto():
            # Un OK que venia de camino elegiria el perfil que este bajo el
            # cursor sin que nadie lo haya querido.
            manager.log("selector: pulsacion ignorada, recien abierto")
            return

        if controlId == REMEMBER_ID:
            self._toggle_remember()
            return

        control = self.actions if controlId == ACTIONS_ID else self.list
        item = control.getSelectedItem()
        if not item:
            return
        uid = item.getProperty("uid")

        # ---- Volver a menu de kodi ----
        if uid == "__back__":
            self._capture_active()  # red de seguridad antes de salir
            self.motivo_cierre = "volver"
            self.close()
            return
        # ---- Limpiar usuario ----
        if uid == "__clear__":
            manager.clear_trakt_session()  # limpia los settings del addon objetivo
            xbmcgui.Dialog().ok("MultiUser", "Sesión Trakt eliminada.")
            return
        # ---- Añadir usuario ----
        if uid == "__add__":
            name = xbmcgui.Dialog().input("Nombre del usuario")
            if not name:
                return

            creado = []

            def mutator(db):
                # generar id único incremental
                new_uid = f"user_{len(db['users']) + 1}"

                # evitar colisiones si se borra alguno
                while new_uid in db["users"]:
                    number = int(new_uid.split("_")[1]) + 1
                    new_uid = f"user_{number}"

                db["users"][new_uid] = {
                    "name": name,
                    "access": "",
                    "refresh": "",
                    "slug": "",
                    "expires": "",
                    "avatar": avatar_libre(db),
                }
                creado.append(new_uid)
                return True

            self._apply(mutator)

            # Cuenta nueva = entrar como ella. _activate deja Palantir sin
            # tokens (nace vacia) y lo relanza, asi que el addon objetivo
            # pide el login de Trakt y el vigilante captura el token solo.
            #
            # Ojo: el active_user lo pone _activate, no el mutator. Si se
            # pusiera aqui se perderia la red de seguridad que guarda el
            # token del perfil anterior antes de dejarlo.
            self._activate(creado[0])
            return

        # ---- Capturar sesión manual ----
        if uid == "__capture__":
            done = []

            def mutator(db):
                active = db.get("active_user")
                if not active or active not in db["users"]:
                    return False
                ok = manager.capture_from_target(active, db)
                done.append(ok)
                return ok

            self._apply(mutator)

            if done and done[0]:
                self.refresh()
                xbmcgui.Dialog().ok("MultiUser", "Sesión capturada correctamente")
            else:
                xbmcgui.Dialog().ok("MultiUser", "No hay ninguna sesión nueva que capturar")
            return

        # ---- Seleccionar usuario ----
        self._activate(uid)

    def _activate(self, uid):
        """Entrar como `uid`: marcarlo activo, inyectar y abrir el objetivo.

        Es el final comun de las dos ramas del selector: elegir un perfil de
        siempre y crear uno nuevo. Las dos acaban igual, con Palantir abierto
        y cargado con los tokens (o sin ninguno) de ese perfil.
        """
        # Quien estaba dentro antes del cambio. Se apunta desde el mutator,
        # que es el que ve el db recien leido del disco: la copia de la
        # ventana puede estar vieja si el vigilante ha escrito entre medias.
        saliente = {}

        def mutator(db):
            # Red de seguridad: guardar el token actual del usuario activo
            # antes de cambiar a otro (por si Trakt lo refrescó y aún no se
            # capturó).
            prev = db.get("active_user")
            saliente["uid"] = prev
            if prev and prev != uid and prev in db["users"]:
                manager.capture_from_target(prev, db)
                # De quien era la sesion que dejamos: si el perfil nuevo se
                # queda sin enlazar, es a este a quien hay que volver.
                db["previous_user"] = prev
            db["active_user"] = uid
            return True

        self._apply(mutator)

        if uid not in self.db["users"]:
            self.refresh()
            return

        user = self.db["users"][uid]
        manager.log(f"Selected uid={uid} access={bool(user.get('access'))} "
                    f"refresh={bool(user.get('refresh'))} slug={user.get('slug','')}")

        # El historial de visto va antes que los tokens: asi Palantir, en
        # cuanto se relance con la sesion nueva, ya encuentra en watched.db
        # lo de este perfil y no lo del anterior. Al reves se asomaria un
        # instante al monton del otro.
        manager.cambiar_watched(saliente.get("uid"), uid)

        # Con tokens  → se inyectan y se abre Palantir ya logueado.
        # Sin tokens  → inject deja Palantir limpio para el login nuevo;
        #               el vigilante (service.py) capturará el token solo.
        manager.inject(uid, self.db)

        self.motivo_cierre = "perfil elegido"
        self.close()
        manager.launch_target()

    def onAction(self, action):

        ACTION_BACK = 10
        ACTION_PREVIOUS_MENU = 92
        ACTION_CONTEXT_MENU = 117
        ACTION_MOUSE_RIGHT_CLICK = 101

        action_id = action.getId()

        # cerrar ventana
        if action_id in (ACTION_BACK, ACTION_PREVIOUS_MENU):
            if self._recien_abierto():
                manager.log("selector: Atras ignorado, recien abierto")
                return
            self._capture_active()  # red de seguridad antes de salir
            self.motivo_cierre = "atras"
            self.close()
            return

        # menu contextual usuario
        if action_id in (ACTION_CONTEXT_MENU, ACTION_MOUSE_RIGHT_CLICK):
            if self.context_open:
                return

            # Las acciones tienen su propio control en la rejilla; sin esto
            # el clic derecho ahi abriria el menu del perfil seleccionado
            # arriba, que no es lo que el usuario esta senalando.
            try:
                if self.getFocusId() != LIST_ID:
                    return
            except Exception:
                pass

            item = self.list.getSelectedItem()
            if not item:
                return

            uid = item.getProperty("uid")

            if uid.startswith("__"):
                return

            self.context_open = True
            self.open_user_menu(uid)
            self.context_open = False

    def open_user_menu(self, uid):
        options = [
            "Editar nombre",
            "Cambiar avatar",
            "Limpiar token",
            "Borrar usuario"
        ]

        choice = xbmcgui.Dialog().select("Opciones de usuario", options)
        # bloquear nuevo evento de contexto
        self.context_open = True
        xbmc.sleep(300)
        self.context_open = False

        if choice == -1:
            return

        if choice == 0:
            self.edit_user(uid)
            return

        elif choice == 1:
            self.edit_avatar(uid)
            return

        elif choice == 2:
            self.clear_tokens(uid)
            return

        elif choice == 3:
            self.delete_user(uid)
            return

    def edit_user(self, uid):
        user = self.db["users"].get(uid)
        if not user:
            return

        new_name = xbmcgui.Dialog().input(
            "Nuevo nombre",
            defaultt=user["name"]
        )
        if not new_name:
            return

        def mutator(db):
            if uid not in db["users"]:
                return False
            db["users"][uid]["name"] = new_name
            return True

        self._apply(mutator)
        self.refresh()

    def edit_avatar(self, uid):
        """Elegir avatar de los que trae el addon.

        useDetails=True es lo que hace que Kodi pinte cada opcion con su
        imagen en vez de una lista de nombres a secas. Si el skin de turno
        no lo respeta, los nombres son colores y siguen sirviendo.
        """
        user = self.db["users"].get(uid)
        if not user:
            return

        disponibles = avatares()
        if not disponibles:
            xbmcgui.Dialog().ok("MultiUser", "No hay avatares instalados.")
            return

        opciones = []
        for nombre in disponibles:
            item = xbmcgui.ListItem(label=nombre.capitalize())
            ruta = os.path.join(AVATARS_DIR, f"{nombre}.png")
            item.setArt({"icon": ruta, "thumb": ruta})
            opciones.append(item)

        try:
            elegido = xbmcgui.Dialog().select(
                "Elige un avatar", opciones, useDetails=True)
        except TypeError:
            # Kodi viejo sin useDetails: se cae a la lista de nombres.
            elegido = xbmcgui.Dialog().select(
                "Elige un avatar", [n.capitalize() for n in disponibles])

        if elegido == -1:
            return

        nombre = disponibles[elegido]

        def mutator(db):
            if uid not in db["users"]:
                return False
            db["users"][uid]["avatar"] = nombre
            return True

        self._apply(mutator)
        self.refresh()

    def clear_tokens(self, uid):
        # El slug hay que leerlo antes de borrarlo: es con lo que Palantir
        # tiene apuntadas las listas que se eligieron para esa cuenta.
        datos = {}

        def mutator(db):
            if uid not in db["users"]:
                return False
            datos["slug"] = db["users"][uid].get("slug", "")
            datos["activo"] = db.get("active_user") == uid
            db["users"][uid].update({
                "access": "",
                "refresh": "",
                "slug": "",
                "expires": ""
            })
            return True

        self._apply(mutator)

        # Limpiar el token es desvincular la cuenta, asi que se va tambien
        # su rastro local. Si no, al volver a vincularla Palantir se
        # encuentra la fecha de la ultima sincronizacion ya puesta, decide
        # que no hay listas nuevas y no vuelve a sacar la ventana de
        # elegirlas, que solo sale al iniciar sesion.
        if datos:
            manager.olvidar_cuenta(uid, datos.get("slug", ""),
                                   datos.get("activo", False))
        self.refresh()

        xbmcgui.Dialog().ok(
            "MultiUser",
            "Tokens eliminados del usuario"
        )

    def delete_user(self, uid):
        confirm = xbmcgui.Dialog().yesno(
            "Eliminar usuario",
            "¿Seguro que quieres borrar este usuario?"
        )

        if not confirm:
            return

        datos = {}

        def mutator(db):
            if uid not in db["users"]:
                return False
            datos["slug"] = db["users"][uid].get("slug", "")
            datos["activo"] = db.get("active_user") == uid
            del db["users"][uid]
            if db.get("active_user") == uid:
                db["active_user"] = None
            return True

        self._apply(mutator)
        # Su rastro se va con el. Si no, el dia que se cree otro perfil y le
        # toque el mismo uid heredaria lo que veia el borrado.
        if datos:
            manager.olvidar_cuenta(uid, datos.get("slug", ""),
                                   datos.get("activo", False))
        self.refresh()





