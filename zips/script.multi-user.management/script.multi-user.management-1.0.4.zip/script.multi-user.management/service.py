# -*- coding: utf-8 -*-
import re
import time

import xbmc
import xbmcaddon
from resources.lib import manager
from resources.lib.ui import open_selector
from resources.lib.watcher import TargetWatcher

ADDON = xbmcaddon.Addon()

# Intervalos de la reconciliacion de tokens (segundos)
FAST_POLL = 3    # mientras hay un usuario activo pendiente de vincular
SLOW_POLL = 30   # mantenimiento: detectar refrescos de token de Trakt

# Cadencia del vigilante de navegacion, solo si esta activado el ajuste.
# Cuanto mas corta, mas posibilidades de llegar antes de que el addon
# objetivo abra un dialogo propio y nos bloquee.
NAV_TICK = 0.25

# Tope de espera a que no quede ningun dialogo abierto. Generoso, porque
# puede haber uno del addon objetivo esperando a que el usuario lo lea.
DIALOG_TIMEOUT = 60.0



def show_selector():
    open_selector()


def ask_on_start():
    try:
        return ADDON.getSettingBool("ask_profile_on_start")
    except Exception:
        return False


def active_is_pending(db):
    """True si el usuario activo todavia no tiene token (esperando vinculacion)."""
    active = db.get("active_user")
    if not active or active not in db.get("users", {}):
        return False
    return not (db["users"][active].get("access"))


def should_prompt_for(db):
    """Politica: preguntar siempre, o solo si el perfil activo no tiene sesion."""
    # La casilla del selector manda sobre lo demas: si se ha pedido no
    # preguntar, se entra directo con el perfil activo. Sin perfil activo si
    # se pregunta, o no habria forma de elegir el primero.
    if db.get("remember") and db.get("active_user"):
        return False
    if not manager.intercept_only_pending():
        return True
    return not db.get("active_user") or active_is_pending(db)


def ruta_vista(path):
    """Donde esta el usuario de verdad, no la ruta que Kodi arrastra.

    Container.FolderPath es la del ultimo listado y se queda puesta aunque
    el usuario este en el menu de inicio: al arrancar Kodi ya viene con la
    del addon objetivo de la sesion anterior. Quien dice la verdad es la
    ventana activa.

    - Fuera de la ventana del listado: estamos fuera, diga lo que diga la
      ruta.
    - En la ventana del listado y con ruta: esa es la buena.
    - En la ventana del listado y sin ruta: no dice nada (el addon esta
      reconstruyendo su listado). Devuelve None y esa lectura se tira, que
      apuntarla como salida convierte el listado siguiente en una entrada
      nueva.
    - Con algo reproduciendose: tampoco dice nada. El reproductor tapa la
      ventana del listado, pero se esta viendo algo del propio addon
      objetivo; no se ha ido a ningun sitio.
    """
    # Reproduciendo: la ventana del reproductor tapa la del listado, pero no
    # se ha salido del addon objetivo, se esta viendo algo suyo. Decir
    # "fuera" aqui convertia el final de cada pelicula en una entrada nueva
    # y sacaba el selector al terminar de ver algo.
    if xbmc.getCondVisibility("Player.HasMedia"):
        return None

    if not xbmc.getCondVisibility(f"Window.IsActive({manager.VIDEO_WINDOW})"):
        return ""
    return path or None


def nombre_objetivo():
    """El nombre bonito del addon objetivo, para hablarle al usuario de el.

    Sin las etiquetas de color de Kodi: Palantir lleva su nombre envuelto en
    [COLOR gold]...[/COLOR] y en una notificacion eso se lee tal cual.
    """
    try:
        target = manager.get_target()
        nombre = target.getAddonInfo("name") if target else ""
    except Exception:
        nombre = ""
    nombre = re.sub(r"\[/?COLOR[^\]]*\]", "", nombre or "").strip()
    return nombre or "el addon"


def aviso_de_arranque(db):
    """Con quien entras y que va a pasar, nada mas abrir Kodi.

    Es el unico momento en que el usuario ve algo sin haberlo pedido, asi
    que es donde toca decirle si al entrar en el addon objetivo se le va a
    preguntar o va a entrar directo. Sin esto, la casilla de "no preguntar"
    es invisible hasta que uno se extrana de que el selector no salga.

    Devuelve (titulo, detalle) ademas de notificarlo, para poder probarlo.
    """
    activo = db.get("active_user")
    usuarios = db.get("users", {})
    objetivo = nombre_objetivo()

    if not activo or activo not in usuarios:
        titulo = "Sin usuario activo"
        detalle = "Inicio con seleccion de usuario"
    else:
        titulo = f"Usuario activo: {usuarios[activo].get('name', activo)}"
        if not usuarios[activo].get("access"):
            detalle = f"Sin sesion: {objetivo} pedira vincular"
        elif db.get("remember"):
            detalle = f"Inicio automatico de {objetivo}"
        else:
            detalle = "Inicio con seleccion de usuario"

    manager.notify(titulo, detalle, 7000)
    manager.log(f"arranque: {titulo} / {detalle}")
    return titulo, detalle


def volver_al_anterior(db):
    """Si el perfil activo sigue sin enlazar al salir, devuelve el mando.

    Un perfil sin token tiene que poder ser el activo mientras se enlaza:
    es la unica forma de saber de quien es la sesion que aparece. Lo que no
    puede es quedarse activo cuando el usuario se va sin enlazarlo, porque
    entonces cada entrada en el addon objetivo vuelve a pedir la
    vinculacion y no hay manera de salir de ahi.

    Se hace al salir y no al volver a entrar a proposito: en ese momento el
    usuario esta en el menu de Kodi, asi que el cambio no se ve y no hay
    que relanzar nada. Al entrar habria que tragarse otra vez la pantalla
    de vinculacion antes de reaccionar.
    """
    if not active_is_pending(db):
        return None

    reserva = manager.perfil_de_reserva(db)
    if not reserva:
        # El primer perfil que se crea no tiene a donde volver.
        return None

    def mutator(fresco):
        # Se relee del disco: puede que el vigilante haya capturado el
        # token entre medias, y entonces ya no hay nada que devolver.
        if not active_is_pending(fresco):
            return False
        fresco["active_user"] = reserva
        fresco["previous_user"] = None
        return True

    nuevo = manager.update_db(mutator)
    if nuevo.get("active_user") != reserva:
        return None

    manager.inject(reserva, nuevo)
    nombre = nuevo["users"][reserva].get("name", reserva)
    manager.log(f"el perfil activo se quedo sin enlazar, se vuelve a {reserva}")
    manager.notify("MultiUser", f"Sin vincular; se vuelve a {nombre}")
    return reserva


def dialog_abierto():
    """True si hay cualquier dialogo por delante.

    No basta con mirar el de ocupado: Kodi rechaza activar una ventana
    mientras haya CUALQUIER modal, y el addon objetivo puede abrir el suyo
    (por ejemplo el de vinculacion de Trakt) antes de que lleguemos.
    """
    return (xbmc.getCondVisibility("System.HasActiveModalDialog")
            or xbmc.getCondVisibility("System.HasVisibleModalDialog")
            or xbmc.getCondVisibility("Window.IsActive(busydialognocancel)")
            or xbmc.getCondVisibility("Window.IsActive(busydialog)"))


def wait_for_dialogs(monitor):
    """Espera a que no quede ningun dialogo delante.

    Devuelve False si se agota el tiempo: en ese caso NO se intenta abrir,
    porque Kodi lo rechazaria y solo se ensuciaria el log.
    """
    limite = time.time() + DIALOG_TIMEOUT
    while time.time() < limite:
        if not dialog_abierto():
            return True
        if monitor.waitForAbort(0.2):
            return False
    manager.log("watcher: hay un dialogo que no se cierra, no se abre el selector")
    return False


if __name__ == "__main__":

    monitor = xbmc.Monitor()

    # Espera a que Kodi termine de arrancar, sin bloquear el apagado. Se
    # espera a que haya interfaz montada en vez de contar seis segundos
    # fijos: el aviso de arranque tiene que salir cuanto antes, porque el
    # usuario le da al addon objetivo a los tres o cuatro segundos, y una
    # notificacion lanzada mientras Kodi todavia pinta no se ve.
    for _ in range(30):
        if (xbmc.getCondVisibility("Window.IsActive(home)")
                or xbmc.getCondVisibility(
                    f"Window.IsActive({manager.VIDEO_WINDOW})")):
            break
        if monitor.waitForAbort(0.2):
            raise SystemExit

    db = manager.load_db()
    active = db.get("active_user")

    # Mejora 6A: avisar de quien es la sesion activa al volver, y de que
    # va a pasar al entrar en el addon objetivo.
    aviso_de_arranque(db)

    # Traza de arranque. Sin esto, un servicio que no abre nada es
    # indistinguible de un servicio que no esta corriendo.
    manager.log(f"servicio arrancado: objetivo={manager.target_addon_id()} "
                f"intercept={manager.intercept_enabled()} "
                f"solo_pendientes={manager.intercept_only_pending()} "
                f"activo={active}")

    watcher = TargetWatcher(manager.target_addon_id())

    # A proposito se arranca "fuera", sin sembrar la ruta actual: este
    # servicio tarda seis segundos en despertar y el usuario entra antes, en
    # cuanto Kodi le pinta el menu. Si al abrir el ojo ya estamos dentro del
    # addon objetivo es que ha entrado el, y esa entrada hay que atenderla
    # aunque no la hayamos visto ocurrir.
    #
    # De la ruta rancia que Kodi arrastra de la sesion anterior ya se
    # encarga ruta_vista(): sin la ventana del listado delante, estamos
    # fuera diga lo que diga.
    watcher.sembrar("")

    # Mostrar selector si no hay usuario activo, o si se ha pedido el modo
    # "preguntar al arrancar" (opcion C, configurable).
    if not active or (ask_on_start() and not db.get("remember")):
        show_selector()
        # Si el usuario ha elegido perfil, la ventana ya ha lanzado el addon
        # objetivo. Esa entrada la hemos provocado nosotros: si el vigilante
        # la viera como un flanco normal volveria a preguntar al instante.
        watcher.assume_inside(time.time())

    next_reconcile = 0.0

    while not monitor.abortRequested():
        now = time.time()
        intercept = manager.intercept_enabled()

        # --- Vigilante de navegacion: se ha entrado en el addon objetivo ---
        # Kodi no anuncia la apertura de un plugin, asi que se mira la ruta
        # del contenedor. Cuando esto dispara, Palantir ya esta cargando: se
        # reacciona, no se intercepta.
        # None = la lectura no dice nada y se tira (ver ruta_vista).
        path = (ruta_vista(xbmc.getInfoLabel("Container.FolderPath") or "")
                if intercept else None)

        if path is not None:
            # Salir del objetivo con el perfil activo aun sin enlazar
            # significa que no se llego a vincular: se devuelve el mando al
            # perfil de antes, aqui, mientras no hay nada delante.
            if watcher.salida(path):
                volver_al_anterior(manager.load_db())

            # Traza puntual: cuando el selector NO sale no se escribe nada,
            # y sin rastro no hay forma de saber si es que no se vio la
            # entrada o si el silencio se la comio.
            if watcher.inside(path) and not watcher.inside(watcher.prev):
                if now < watcher.suppress_until:
                    manager.log("watcher: entrada tapada por el silencio "
                                f"({watcher.suppress_until - now:.1f}s por delante)")

            if watcher.should_prompt(path, now):
                if manager.consumir_relanzado():
                    # Esta entrada la hemos provocado nosotros al elegir
                    # perfil: se apunta como atendida y no se pregunta, o
                    # seria un bucle. Las del usuario no llevan marca y
                    # pasan siempre, aunque entre y salga a toda prisa.
                    manager.log("watcher: la entrada es del relanzado, "
                                "no se pregunta")
                elif should_prompt_for(manager.load_db()):
                    manager.log(f"watcher: entrada en {path}, abriendo selector")
                    if wait_for_dialogs(monitor):
                        # Al elegir perfil la ventana inyecta y relanza el
                        # addon objetivo. Kodi lo invoca de nuevo y este
                        # lee el token del disco, asi que aqui no queda
                        # nada que hacer.
                        show_selector()
                else:
                    # Callarse aqui es lo que hace que el addon parezca roto:
                    # se ha entrado en el objetivo y no se abre nada. Es el
                    # caso de "solo si el perfil activo no tiene sesion" con
                    # un perfil que si la tiene.
                    manager.log(f"watcher: entrada en {path}, pero no toca "
                                f"preguntar (solo_pendientes="
                                f"{manager.intercept_only_pending()})")
                watcher.handled(time.time(), path)

        # --- Reconciliacion de tokens (auto-captura y refrescos de Trakt) ---
        if now >= next_reconcile:
            db = manager.load_db()

            name = manager.reconcile_active(db)
            if name:
                manager.notify("MultiUser", f"Sesion de {name} guardada")

            next_reconcile = now + (FAST_POLL if active_is_pending(db) else SLOW_POLL)

        interval = NAV_TICK if intercept else (
            FAST_POLL if active_is_pending(db) else SLOW_POLL)

        if monitor.waitForAbort(interval):
            break
