# -*- coding: utf-8 -*-
import json
import os
import sqlite3
import time
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()

# Valores por defecto. Se pueden sobreescribir desde los ajustes del addon
# (settings.xml) sin tocar el codigo.
DEFAULT_TARGET_ID = "plugin.video.palantir3"
# Cache de listados del addon objetivo. Es la tabla que usa el modulo
# simplecache, comun en los addons de Kodi.
DEFAULT_CACHE_DB = "cache.db"
CACHE_TABLE = "simplecache"

# Ventana de video de Kodi, la que muestra el listado del addon objetivo.
VIDEO_WINDOW = 10025

# Ventana de inicio, que es la unica que sigue viva de principio a fin. Sus
# propiedades son el buzon entre procesos: el selector puede correr en el
# del servicio o en el de un script, y asi se entienden igual.
HOME_WINDOW = 10000
RELAUNCH_PROP = "multiuser.relanzado"

DEFAULT_KEYS = {
    "access": "trakt_access_token",
    "refresh": "trakt_refresh_token",
    "slug": "trakt_slug",
    "expires": "trakt_token_expired_at",
}


def log(msg):
    xbmc.log(f"[MULTIUSER] {msg}", xbmc.LOGINFO)


def notify(title, msg, time_ms=5000):
    try:
        xbmcgui.Dialog().notification(title, msg, xbmcgui.NOTIFICATION_INFO, time_ms)
    except Exception as e:
        log(f"notify() error: {e}")


# ---------------------------------------------------------------------------
# Configuracion (lee de settings.xml, con fallback a los valores por defecto)
# ---------------------------------------------------------------------------
def _setting(key, default):
    try:
        val = ADDON.getSetting(key)
    except Exception:
        val = ""
    return val if val else default


def _setting_bool(key, default=False):
    try:
        return ADDON.getSettingBool(key)
    except Exception:
        return default


def target_addon_id():
    return _setting("target_addon_id", DEFAULT_TARGET_ID)


def intercept_enabled():
    """Abrir el selector al entrar en el addon objetivo."""
    return _setting_bool("intercept_target")


def intercept_only_pending():
    """Preguntar solo si el perfil activo no tiene sesion."""
    return _setting_bool("intercept_only_pending")


def purge_cache_enabled():
    """Vaciar la cache del addon objetivo al cambiar de perfil."""
    return _setting_bool("purge_target_cache", True)


def cache_db_name():
    return _setting("cache_db_name", DEFAULT_CACHE_DB)



def txt(string_id, fallback=""):
    """Cadena traducida del addon, con texto de reserva si no hay .po."""
    try:
        return ADDON.getLocalizedString(string_id) or fallback
    except Exception:
        return fallback


def keys():
    return {
        "access": _setting("access_key", DEFAULT_KEYS["access"]),
        "refresh": _setting("refresh_key", DEFAULT_KEYS["refresh"]),
        "slug": _setting("slug_key", DEFAULT_KEYS["slug"]),
        "expires": _setting("expires_key", DEFAULT_KEYS["expires"]),
    }


def marcar_relanzado():
    """Deja dicho que la proxima entrada en el objetivo la provocamos aqui.

    El vigilante no puede distinguir por la ruta si el addon objetivo lo ha
    abierto el usuario o lo hemos relanzado nosotros al elegir perfil, y sin
    distinguirlo se entra en bucle: relanzas, lo ve como entrada, abre el
    selector, que relanza otra vez. Antes se tapaba callando unos segundos,
    pero eso se tragaba tambien las entradas de verdad del usuario si volvia
    rapido. Marcarlo es exacto y no depende del reloj.
    """
    try:
        xbmcgui.Window(HOME_WINDOW).setProperty(RELAUNCH_PROP, str(time.time()))
    except Exception as e:
        log(f"marcar_relanzado() error: {e}")


def consumir_relanzado(caducidad=60.0):
    """True si la entrada que se acaba de ver la provocamos nosotros.

    Se consume: solo vale para una entrada. Y caduca, porque si el usuario
    cierra el objetivo antes de que Kodi llegue a pintarlo, la marca se
    quedaria puesta esperando a una entrada que ya no viene.
    """
    try:
        ventana = xbmcgui.Window(HOME_WINDOW)
        marca = ventana.getProperty(RELAUNCH_PROP)
        if not marca:
            return False
        ventana.clearProperty(RELAUNCH_PROP)
        return (time.time() - float(marca)) < caducidad
    except Exception as e:
        log(f"consumir_relanzado() error: {e}")
        return False


def get_target():
    """Devuelve el addon objetivo (Palantir) o None si no esta instalado."""
    try:
        return xbmcaddon.Addon(target_addon_id())
    except Exception as e:
        log(f"No se pudo abrir el addon objetivo '{target_addon_id()}': {e}")
        return None


# ---------------------------------------------------------------------------
# Base de datos local (users.json)
# ---------------------------------------------------------------------------
def profile_path():
    path = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
    return path


def db_path():
    return profile_path() + "users.json"


def _empty_db():
    return {"active_user": None, "users": {}, "remember": False}


def _quarantine(path, reason):
    """Aparta un users.json ilegible en vez de borrarlo en silencio.

    Perder todos los perfiles sin dejar rastro es peor que cualquier error:
    se guarda una copia con marca de tiempo y se avisa al usuario.
    """
    stamp = time.strftime("%Y%m%d-%H%M%S")
    dest = f"{path}.corrupt-{stamp}"

    # Dos corrupciones en el mismo segundo no deben pisarse la copia.
    n = 1
    while xbmcvfs.exists(dest):
        dest = f"{path}.corrupt-{stamp}-{n}"
        n += 1

    try:
        xbmcvfs.copy(path, dest)
        xbmcvfs.delete(path)
        log(f"_quarantine() {reason} -> copia en {dest}")
        notify("MultiUser", "users.json ilegible; se ha guardado una copia")
    except Exception as e:
        log(f"_quarantine() error apartando {path}: {e}")


def load_db():
    path = db_path()

    if not xbmcvfs.exists(path):
        db = _empty_db()
        save_db(db)
        return db

    f = xbmcvfs.File(path)
    try:
        data = f.read()
    finally:
        f.close()

    if not data.strip():
        db = _empty_db()
        save_db(db)
        return db

    try:
        db = json.loads(data)
    except Exception as e:
        _quarantine(path, f"JSON invalido ({e})")
        db = _empty_db()
        save_db(db)
        return db

    # Estructura minima, por si el fichero se edito a mano.
    if not isinstance(db, dict) or not isinstance(db.get("users"), dict):
        _quarantine(path, "estructura invalida")
        db = _empty_db()
        save_db(db)
        return db

    db.setdefault("active_user", None)
    # "No preguntar al entrar en el addon objetivo". Vive aqui y no en los
    # ajustes del addon a proposito: el vigilante corre en el proceso del
    # servicio y relee este fichero del disco en cada comprobacion, asi que
    # el cambio le llega en el acto. Un ajuste escrito desde la ventana
    # podria quedarse en su proceso hasta que Kodi lo recargue, y una
    # casilla que se ve marcada y no hace nada es peor que no tenerla.
    db.setdefault("remember", False)
    return db


def save_db(db):
    """Escritura atomica: primero al temporal, luego swap.

    Si se corta la luz a mitad de escritura, el users.json anterior queda
    intacto en vez de convertirse en un JSON truncado que load_db() daria
    por corrupto.
    """
    path = db_path()
    tmp = path + ".tmp"

    f = xbmcvfs.File(tmp, "w")
    try:
        f.write(json.dumps(db, indent=2))
    finally:
        f.close()

    # os.replace es atomico y sobrescribe, en Windows y en POSIX. El perfil
    # del addon siempre es una ruta local, asi que se puede usar os directo.
    os.replace(tmp, path)


def update_db(mutator):
    """Aplica un cambio sobre la version mas reciente del disco.

    La ventana mantiene su copia del db viva mientras esta abierta, y el
    vigilante de service.py escribe cada pocos segundos. Guardar la copia
    de la ventana tal cual pisaria los tokens capturados entre medias, asi
    que toda escritura relee primero.

    `mutator` recibe el db fresco y devuelve True si hay que guardarlo.
    Devuelve el db resultante, para que el llamante refresque su copia.
    """
    db = load_db()
    if mutator(db):
        save_db(db)
    return db


# ---------------------------------------------------------------------------
# Inyeccion / captura de tokens en el addon objetivo
# ---------------------------------------------------------------------------
def inject(uid, db):
    """Carga los tokens del usuario `uid` en los ajustes de Palantir."""
    target = get_target()
    if target is None:
        notify("MultiUser", "El addon objetivo no esta instalado")
        return

    user = db["users"][uid]
    k = keys()

    target.setSetting(k["access"], user.get("access", ""))
    target.setSetting(k["refresh"], user.get("refresh", ""))
    target.setSetting(k["slug"], user.get("slug", ""))
    target.setSetting(k["expires"], user.get("expires", ""))

    log(f"inject() uid={uid} access_len={len(user.get('access',''))} "
        f"slug={user.get('slug','')} expires={user.get('expires','')}")

    # Sin esto el addon objetivo sigue mostrando las listas cacheadas del
    # perfil anterior hasta que caduquen.
    purge_target_cache()


def target_profile_path():
    """Carpeta de datos del addon objetivo. None si no esta instalado."""
    target = get_target()
    if target is None:
        return None
    return xbmcvfs.translatePath(target.getAddonInfo("profile"))


def purge_target_cache():
    """Vacia la cache de listados del addon objetivo.

    Palantir cachea el resultado de las listas de Trakt con una clave que no
    incluye la cuenta: al cambiar de perfil sigue sirviendo lo del anterior
    hasta que caduque, y salen listas que no son de ese usuario.

    Vaciarla no pierde nada suyo. Es cache con caducidad, el propio addon la
    tira sola cada pocos minutos; lo unico que cuesta es que la primera carga
    tras cambiar de perfil va mas lenta.

    Se vacia SOLO esa tabla. Ni se borra el fichero ni se tocan las demas,
    para no llevarse por delante nada que el addon objetivo guarde ahi
    (el historial de visto, por ejemplo, vive en otro sitio).
    """
    if not purge_cache_enabled():
        return False

    base = target_profile_path()
    if not base:
        return False

    path = os.path.join(base, cache_db_name())
    if not xbmcvfs.exists(path):
        log(f"purge_target_cache() no existe {path}")
        return False

    try:
        # timeout por si el addon objetivo tiene la base abierta ahora mismo
        con = sqlite3.connect(path, timeout=2.0)
        try:
            tablas = [r[0] for r in con.execute(
                "SELECT name FROM sqlite_master WHERE type='table'")]
            if CACHE_TABLE not in tablas:
                log(f"purge_target_cache() no hay tabla '{CACHE_TABLE}' "
                    f"en {path} (hay: {tablas})")
                return False

            n = con.execute(f"SELECT COUNT(*) FROM {CACHE_TABLE}").fetchone()[0]
            con.execute(f"DELETE FROM {CACHE_TABLE}")
            con.commit()
        finally:
            con.close()

        log(f"purge_target_cache() {n} filas borradas de {path}")
        return True
    except Exception as e:
        # Que la cache no se deje vaciar no puede impedir el cambio de perfil.
        log(f"purge_target_cache() error: {e}")
        return False


def clear_trakt_session():
    """Vacia los tokens de Trakt en el addon objetivo."""
    target = get_target()
    if target is None:
        return
    k = keys()
    target.setSetting(k["access"], "")
    target.setSetting(k["refresh"], "")
    target.setSetting(k["slug"], "")
    target.setSetting(k["expires"], "")
    log("clear_trakt_session() done")


def read_target_tokens():
    """Lee los tokens actuales del addon objetivo. None si no esta instalado."""
    target = get_target()
    if target is None:
        return None
    k = keys()
    return {
        "access": target.getSetting(k["access"]),
        "refresh": target.getSetting(k["refresh"]),
        "slug": target.getSetting(k["slug"]),
        "expires": target.getSetting(k["expires"]),
    }


def capture_from_target(uid, db):
    """Copia el token actual de Palantir al usuario `uid`.

    Devuelve True solo si habia un token nuevo (distinto y no vacio) que
    realmente se ha guardado. Nunca sobreescribe con vacio.
    """
    tokens = read_target_tokens()
    if tokens is None:
        return False

    new_access = tokens.get("access") or ""
    if not new_access:
        return False  # Palantir no tiene sesion -> nada que capturar

    # Un token que ya es de OTRO perfil no se adopta. Si aparece aqui es que
    # Palantir sigue con la sesion anterior cargada, no que este usuario se
    # haya logueado: adoptarlo dejaria dos perfiles con la misma cuenta.
    for other_uid, other in db.get("users", {}).items():
        if other_uid != uid and (other.get("access") or "") == new_access:
            log(f"capture_from_target() el token ya es de uid={other_uid}, "
                f"no se copia a uid={uid}")
            return False

    user = db["users"][uid]
    if (user.get("access") or "") == new_access:
        # Mismo token, pero el slug puede llegar tarde: Palantir lo escribe
        # un instante despues que el access, y si capturamos justo en medio
        # nos quedamos con el vacio PARA SIEMPRE, porque aqui solo se compara
        # el access. Y un perfil sin slug hace que Palantir no sepa que
        # listas son suyas.
        late_slug = tokens.get("slug") or ""
        if late_slug and not (user.get("slug") or ""):
            user["slug"] = late_slug
            user["refresh"] = user.get("refresh") or tokens.get("refresh") or ""
            user["expires"] = user.get("expires") or tokens.get("expires") or ""
            log(f"capture_from_target() slug tardio '{late_slug}' para uid={uid}")
            return True
        return False  # ya lo teniamos

    user["access"] = new_access
    user["refresh"] = tokens.get("refresh") or ""
    user["slug"] = tokens.get("slug") or ""
    user["expires"] = tokens.get("expires") or ""
    log(f"capture_from_target() token guardado para uid={uid}")
    return True


def reconcile_active(db):
    """Auto-captura: si Palantir tiene un token nuevo para el usuario activo,
    lo guarda en users.json. Cubre tanto el alta inicial (vacio -> token)
    como el refresco de Trakt (token viejo -> token nuevo).

    Devuelve el nombre del usuario si se ha guardado algo, si no None.
    """
    active = db.get("active_user")
    if not active or active not in db.get("users", {}):
        return None

    if capture_from_target(active, db):
        save_db(db)
        return db["users"][active].get("name", active)
    return None


def launch_target():
    """Abre el addon objetivo, que se relanza y relee los ajustes del disco.

    Un plugin de Kodi no es un proceso vivo: se invoca, construye el listado
    y muere. Con esto basta para que el objetivo arranque de nuevo y lea el
    token recien inyectado; comprobado en el log, Kodi lo vuelve a invocar.

    Nada de refrescar el contenedor desde aqui: esto corre en el onClick de
    la ventana, con el modal a medio cerrar, y ahi un Container.Refresh
    cierra Kodi.
    """
    target_id = target_addon_id()
    root = f"plugin://{target_id}/"
    marcar_relanzado()
    log(f"launch_target() -> ActivateWindow({VIDEO_WINDOW}, {root})")
    xbmc.executebuiltin(f'ActivateWindow({VIDEO_WINDOW},"{root}",return)')
